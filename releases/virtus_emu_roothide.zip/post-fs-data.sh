#!/system/bin/sh
MODDIR=${0%/*}
TARGET="$MODDIR/target_packages.txt"
sh "$MODDIR/refresh_pkglist.sh" "$MODDIR"
# Emulator module: keep wildcard + refresh user app list for injection.
if [ ! -f "$TARGET" ]; then
  echo '*' > "$TARGET"
fi
if ! grep -qx '*' "$TARGET" 2>/dev/null; then
  echo '*' >> "$TARGET"
fi
PKG="$MODDIR/pkglist.txt"
if [ -f "$PKG" ]; then
  while IFS= read -r line; do
    [ -z "$line" ] && continue
    grep -qx "$line" "$TARGET" 2>/dev/null || echo "$line" >> "$TARGET"
  done < "$PKG"
fi
