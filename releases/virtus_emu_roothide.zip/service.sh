#!/system/bin/sh
MODDIR=${0%/*}
TARGET="$MODDIR/target_packages.txt"
[ -f "$MODDIR/refresh_pkglist.sh" ] && sh "$MODDIR/refresh_pkglist.sh" "$MODDIR"
PKG="$MODDIR/pkglist.txt"
[ -f "$PKG" ] || exit 0
while IFS= read -r line; do
  [ -z "$line" ] && continue
  grep -qx "$line" "$TARGET" 2>/dev/null || echo "$line" >> "$TARGET"
done < "$PKG"
